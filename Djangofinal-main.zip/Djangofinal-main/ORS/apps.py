from django.apps import AppConfig


class OrsConfig(AppConfig):
    name = 'ORS'
